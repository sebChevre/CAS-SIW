package ch.si.beans;

import java.util.ArrayList;

public class Student {
    private String name;
    private boolean working;
    
    private ArrayList<String> languages = new ArrayList<String>();
	
    public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public boolean isWorking() {
		return working;
	}
	public void setWorking(boolean working) {
		this.working = working;
	}
	
	public ArrayList<String> getLanguages() {
		return languages;
	}
	public void setLanguages(ArrayList<String> languages) {
		this.languages = languages;
	}
	public void addLanguage(String language){
		this.languages.add(language);
	}
}

