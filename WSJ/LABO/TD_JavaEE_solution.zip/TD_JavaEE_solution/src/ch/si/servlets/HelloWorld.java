package ch.si.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ch.si.beans.Student;

/**
 * Servlet implementation class HelloWorld
 */
@WebServlet("/HelloWorld")
public class HelloWorld extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HelloWorld() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		response.setContentType("text/html");
//		PrintWriter out = response.getWriter();
//
//		out.println("<html>");
//		out.println("<head>");
//		out.println("<title>Hello world servlet</title>");
//		out.println("</head>");
//		out.println("<body>");
//				
//		out.println("<h1>Hello World Servlet</h1>");
//		out.println("Hello World!");
//				
//		out.println("</body>");
//		out.println("</html>");
//		out.close();
		
		String message = "Message from the servlet!";
		request.setAttribute("msg", message);
		
		Student student = new Student();
		student.setName("Toto");
		student.setWorking(false);
		
		student.addLanguage("c");
		student.addLanguage("c++");
		student.addLanguage("c#");
		student.addLanguage("java");
		
		request.setAttribute("student", student);
		
		
		this.getServletContext().getRequestDispatcher("/WEB-INF/HelloWorld.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		response.setContentType("text/html");
//		PrintWriter out = response.getWriter();
//		
//		String name = request.getParameter("name");
//		
//		out.println("<html>");
//		out.println("<head>");
//		out.println("<title>Hello world servlet</title>");
//		out.println("</head>");
//		out.println("<body>");
//				
//		out.println("<h1>Hello World Servlet</h1>");
//		out.println("<p>Hello " + name + "!");
//				
//		out.println("</body>");
//		out.println("</html>");
//		out.close();
		
		this.getServletContext().getRequestDispatcher("/WEB-INF/HelloWorld.jsp").forward(request, response);
	}

}
